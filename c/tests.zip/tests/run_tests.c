#include <stdio.h>

int test_crypto();
int test_protocol();
int test_connection();

int main() {
    int fails = 0;

    printf("Running tests...\n");

    if (test_crypto()) fails++;
    if (test_protocol()) fails++;
    if (test_connection()) fails++;

    if (fails == 0) {
        printf("ALL TESTS PASSED\n");
    } else {
        printf("%d TEST(S) FAILED\n", fails);
    }

    return fails;
}