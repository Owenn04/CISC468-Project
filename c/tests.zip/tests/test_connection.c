#include "../include/network/connection.h"
#include "../include/crypto/crypto.h"
#include "test_utils.h"

#include <pthread.h>
#include <sys/socket.h>

static void *responder_thread(void *arg) {
    PeerConnection *conn = (PeerConnection *)arg;
    connection_handshake_responder(conn);
    return NULL;
}

int test_connection() {
    printf("test_connection...\n");

    int fds[2];
    socketpair(AF_UNIX, SOCK_STREAM, 0, fds);

    PeerConnection a, b;
    IdentityKeyPair id_a, id_b;

    generate_identity_keypair(&id_a);
    generate_identity_keypair(&id_b);

    connection_init(&a, fds[0], "alice", true);
    connection_init(&b, fds[1], "bob", false);

    connection_set_identity(&a, &id_a);
    connection_set_identity(&b, &id_b);

    pthread_t t;
    pthread_create(&t, NULL, responder_thread, &b);

    ASSERT_EQ(connection_handshake_initiator(&a), P2P_OK);

    pthread_join(t, NULL);

    ASSERT_TRUE(a.handshake_complete);
    ASSERT_TRUE(b.handshake_complete);

    TEST_PASS();
}