#include "../include/crypto/crypto.h"
#include "test_utils.h"
#include <string.h>

int test_crypto() {
    printf("test_crypto...\n");

    IdentityKeyPair id;
    ASSERT_EQ(generate_identity_keypair(&id), P2P_OK);

    unsigned char msg[] = "hello";
    unsigned char nonce[P2P_NONCE_BYTES];
    unsigned char ct[256];
    unsigned char pt[256];
    size_t ct_len = 0, pt_len = 0;

    unsigned char key[32] = {0};

    ASSERT_EQ(encrypt_bytes(key, msg, strlen((char*)msg), nonce, ct, &ct_len), P2P_OK);
    ASSERT_EQ(decrypt_bytes(key, nonce, ct, ct_len, pt, &pt_len), P2P_OK);

    pt[pt_len] = '\0';
    ASSERT_TRUE(strcmp((char*)pt, "hello") == 0);

    TEST_PASS();
}