#include "../include/network/protocol.h"
#include "test_utils.h"

int test_protocol() {
    printf("test_protocol...\n");

    cJSON *payload = build_list_request_payload();
    ASSERT_TRUE(payload != NULL);

    cJSON_Delete(payload);

    TEST_PASS();
}